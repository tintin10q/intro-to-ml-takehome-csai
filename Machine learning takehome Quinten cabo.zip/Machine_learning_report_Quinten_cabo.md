---
title: Machine learning Take-Home Report
date: May 2021
author:
- Quinten Cabo  
numbersections: true
geometry: margin=2cm
lang: "en"
toc-own-page: true
toc: true
---

# Machine learning take home assignment 

Name: Quinten Cabo
SSID: u789241

To run the notebook python 3.9 is required.

## Part 1: Classification of Facial Expressions 
### 1.2.1. 
![The 3 faces with titles](1.2.1.png)

### 1.2.2 
![The histogram plots](1.2.2.png)

#### Is the dataset balanced?
**No**. The dataset is not balanced at all. There are almost double the targets with label 0 vs targets with label 1. Likewise there are almost double the targets with label 1 vs label 2

### 1.3.1 

List the accuracy of the KNN and other metrics you might use. Include two examples of the misclassified images. 

### 1.3.2
K 1 till 87 where checked with steps of 2
The best K was K = 9

This K gave a baseline test score of **0.75** and a baseline train score of **0.76**

![1.3.2 k graph](1.3.2.png)

### 1.3.3 
Create a table of the classifiers you used

| Model 	| DecisionTreeClassifier 	| Kernel Support vector machines 	| Linear support Vector Machines 	| Naive Bayes 	|
|-	|-	|-	|-	|-	|
| Best parameters 	| 'criterion': 'entropy' <br>'splitter': 'random' <br>'max_depth': 16<br>'max_features':'log2'<br>'ccp_alpha': 0.2 	| 'C': 10000<br>'kernel': 'sigmoid' 	| C: 10000 	| None 	|
| Train score 	| 0.63 	| 1.0 	| 1.0 	| 0.5 	|
| Test score 	| 0.70 	| 0.85 	| 0.88 	| 0.52 	|
| Precision score 	| 0.699 0.734 0.6 	| 0.895 0.934 0.627 	| 0.913 0.936 0.714 	| 0.658 0.8 0.266 	|
| Recal score 	| 0.877 0.5625     0.365 	| 0.8442623 0.890625  0.780 	| 0.860 0.921   0.853 	| 0.631 0.25 0.585 	|
| F1 score 	| 0.778 0.637 0.454 	| 0.869 0.912      0.695 	| 0.886 0.929 0.777 	| 0.644 0.380 0.366 	|
| Support 	| 122  64  41 	| 122  64  41 	| 122  64  41 	| 122 64 41 	|
| Training Seconds 	| 0.066977 	| 0.982998 	| 13.961979 	| 0.062515 	|


| Model            | RandomForestClassifier     | Gradient Boosing    | Voting Classifier |
|------------------|----------------------------|---------------------|-------------------|
| Best parameters  | 'n_estimators': 200        | 'n_estimators: 200' | The best models   |
| Train score      | 1.0                        | 1.0                 | 0.861             |
| Test score       | 0.81                       | 0.85                | 0.972             |
| Precision score  | 0.885 0.936 0.542          | 0.896 0.913 0.727   | 0.736 8.98 0.5    |
| Recal score      | 0.762 0.921   0.780        | 0.844 0.890  0.880  | 0.868 0.765 0.341 |
| F1 score         | 0.81938326 0.92913386 0.64 | 0.949 0.952  0.925  | 0.796 0.823 0.405 |
| Support          | 122  64  41                | 122  64  41         | 122  64  41       |
| Training Seconds | 3.101                      | 0.9829              | 20.10             |

#### Which was your best pipeline or classifier and with what parameters?  
The best classifier that I found was a Linear support vector machine with C=10000

#### Did you beat the baseline classifier?
I beat the baseline classifier with all models except Naive Bayes. 

## Part 2: Regression to estimate the width of a grey kangaroo’s nose

### 2.2.1. 
Include the plot you created
![Scatter plot of the nose data](2.2.1.png)

### 2.3.2
List the result of your R2 score 
I got a result of 0.777 

### 2.3.3 
List the result of your mean R2 score 
The Cross validated R2 scores were [ 0.61765389  0.63501709  0.90178865 -1.48731674  0.50294111]
The Mean R2 score was 0.234

### 2.3.4
In a table(preferably), display each regressor with it corresponding score.  Include the figure displaying your solution in a plot.  

| Model     | Linear Regression | Support Vector Regression | Decision Tree Regression |
|-----------|-------------------|---------------------------|--------------------------|
| R2 score | 0.234             | 0.86                      | 0.864                    |

![Different regression techniques](2.2.3.png)

#### Which is the best regressor? 
Decision Tree Regression was the best regressor. 

### 2.4.
| Model    | Mean imputation | KNN imputation (k=3) |
|----------|-----------------|----------------------|
| R2 score | 0.617           | 0.7                  |

#### Which is the best data imputation method? 
The KNN imputation method was the best. With a score of 0.7


#### Resources
